# MN5 Proje Talimatları — Claude için

Bu dosya, MN5 (MareNostrum 5) üzerinde çalışan bir projeye AI asistanı eşliğinde katkı sağlarken dikkat edilmesi gereken bağlamı, kısıtlamaları ve en iyi pratikleri tanımlar. Bu talimatları oku ve tüm önerileri bu çerçevede yap.

---

## Proje Bağlamı

**Platform:** MareNostrum 5 (MN5), Barcelona Supercomputing Center (BSC)
**Partition:** ACC (GPU) — 4× NVIDIA H100 80 GB SXM5 / node
**Proje kodu:** ehpc648  ← bunu kendi proje kodunla değiştir
**Scheduler:** SLURM
**Container runtime:** Singularity / Apptainer (Docker çalışmaz)
**Resmi dokümantasyon:** https://www.bsc.es/supportkc/docs/MareNostrum5/overview/

---

## Dizin Yapısı (MN5 üzerinde)

```
/gpfs/projects/ehpc648/my-project/    ← ana çalışma dizini
├── .claude/CLAUDE.md                 ← bu dosya
├── jobs/                             ← SLURM job script'leri
│   └── templates/                    ← şablon job'lar
├── scripts/                          ← Python / bash script'ler
├── logs/                             ← SLURM job çıktıları (.out / .err)
├── results/                          ← analiz ve benchmark sonuçları
├── docs/                             ← notlar, raporlar
├── models/                           ← LLM model ağırlıkları (sync'e dahil değil)
└── containers/                       ← .sif dosyaları (sync'e dahil değil)
```

**Paylaşımlı BSC container'ları (doğrudan kullan, kopyalama):**
```
/gpfs/scratch/shared/ai-hub/singularity_images/vllm/vllm-v0.18.0-official.sif
/gpfs/scratch/shared/ai-hub/singularity_images/vllm/pytorch_25.12-py3.sif
/gpfs/scratch/shared/ai-hub/singularity_images/vllm/nemo_25.02.sif
```

---

## Kritik Kurallar (Bunları Asla Atlama)

### 1. Tüm job script'lerinde `module purge` zorunludur
```bash
module purge
module load singularity/3.11.5
# module load python  ← YAPMA — PYTHONHOME container'a sızar
```

### 2. Singularity multi-GPU job'larında GPU binding açık belirtilmeli
```bash
# Her task için — CUDA_VISIBLE_DEVICES her zaman 0
export CUDA_VISIBLE_DEVICES=0
export SINGULARITYENV_CUDA_VISIBLE_DEVICES=0
```
Neden: `--gpu-bind=single:1` Singularity container'larına yansımaz. Fiziksel GPU izolasyonu SLURM cgroup'una bırakılır; container GPU'sunu her zaman "index 0" olarak görür.

### 3. MPI kullanan job'larda CPU binding kapatılmalı
```bash
export SLURM_CPU_BIND=none
```

### 4. `srun` ile `--cpus-per-task` her zaman açık belirtilmeli
```bash
srun --cpus-per-task=$SLURM_CPUS_PER_TASK ./program
# veya
export SRUN_CPUS_PER_TASK=$SLURM_CPUS_PER_TASK
```

### 5. Zorunlu SBATCH direktifleri
```bash
#SBATCH --account=ehpc648    # her zaman gerekli
#SBATCH --qos=acc_debug      # her zaman gerekli
```

### 6. Sabit `sleep` yerine health-check döngüsü kullan
```bash
for i in $(seq 1 18); do
  curl -s http://localhost:8000/health | grep -q "ok" && break
  sleep 10
done
```

---

## SLURM Kuyruk Referansı (ACC Partition)

| QoS | Max Node | Wallclock | Ne zaman kullan |
|-----|----------|-----------|-----------------|
| `acc_debug` | 8 node | 2 saat | Geliştirme, test |
| `acc_interactive` | 1 node | 2 saat | İnteraktif oturum |
| `acc_ehpc` | 100 node | 72 saat | Prodüksiyon işler |
| `acc_training` | 4 node | 48 saat | Eğitim amaçlı |

---

## Dosya Transferi Hatırlatıcısı

MN5'ten internet erişimi yok. Tüm transferler yerel makineden:
```bash
# Yerel makineye gönder:
rsync -avz --partial --progress \
  --exclude='models/' --exclude='containers/' --exclude='logs/' --exclude='*.sif' \
  ./ user@transfer1.bsc.es:/gpfs/projects/ehpc648/my-project/
```

---

## Önerilerin Şekli

Bu projede kod veya script yazarken:
- Her zaman SLURM job script'i olarak yaz, doğrudan CLI komutu olarak değil
- GPU bağlama kurallarını otomatik uygula
- `module purge` ile başla
- Çıktı dosyaları için `logs/` dizinini kullan: `#SBATCH --output=logs/%x-%j.out`
- Model yollarını `/gpfs/projects/ehpc648/models/` ile başlat
- Container olarak BSC AI Hub'daki hazır image'ları tercih et
- Yeni script'leri `scripts/` altına, job dosyalarını `jobs/` altına koy

---

## Yardımcı Komutlar

```bash
bsc_project list      # erişilebilir account'lar
bsc_queues            # kullanılabilir QoS
bsc_quota             # depolama kotası
squeue -u $USER       # job kuyruğu
scancel <JOBID>       # job iptal
```
