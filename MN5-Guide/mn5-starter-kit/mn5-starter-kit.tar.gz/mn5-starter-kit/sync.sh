#!/bin/bash
# =============================================================================
# MN5 Sync Script
# Yerel proje dizinini MN5'e rsync ile senkronize eder.
# Modeller, container'lar ve büyük geçici dosyalar hariç tutulur.
#
# Kullanım:
#   ./sync.sh                        # varsayılan kullanıcı adı ($USER)
#   ./sync.sh gokhan                 # açık kullanıcı adı
#   ./sync.sh gokhan my-project      # kullanıcı + proje dizin adı
#   ./sync.sh --dry-run              # değişiklikleri göster, aktarma
# =============================================================================

set -euo pipefail

# --- Ayarlar (projenize göre düzenleyin) ---
MN5_USER="${1:-$USER}"
MN5_HOST="transfer1.bsc.es"
MN5_BASE="/gpfs/projects/ehpc648"
PROJECT_NAME="${2:-$(basename "$(pwd)")}"
MN5_DEST="${MN5_BASE}/${PROJECT_NAME}"

DRY_RUN=0
if [[ "${1:-}" == "--dry-run" ]]; then
  DRY_RUN=1
  shift
fi

# --- Renkler ---
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${GREEN}=== MN5 Sync ===${NC}"
echo "  Kaynak    : $(pwd)"
echo "  Hedef     : ${MN5_USER}@${MN5_HOST}:${MN5_DEST}"
echo ""

# Dry-run uyarısı
if [ $DRY_RUN -eq 1 ]; then
  echo -e "${YELLOW}[DRY-RUN] Gerçek transfer yapılmayacak.${NC}"
fi

# rsync komutu
RSYNC_OPTS="-avz --partial --progress"
if [ $DRY_RUN -eq 1 ]; then
  RSYNC_OPTS="$RSYNC_OPTS --dry-run"
fi

rsync $RSYNC_OPTS \
  --exclude='.git/' \
  --exclude='models/' \
  --exclude='containers/' \
  --exclude='logs/' \
  --exclude='results/' \
  --exclude='*.sif' \
  --exclude='*.tar.gz' \
  --exclude='*.tar' \
  --exclude='*.zip' \
  --exclude='__pycache__/' \
  --exclude='*.pyc' \
  --exclude='.DS_Store' \
  --exclude='*.egg-info/' \
  --exclude='venv/' \
  --exclude='conda-env/' \
  ./ \
  "${MN5_USER}@${MN5_HOST}:${MN5_DEST}/"

echo ""
echo -e "${GREEN}=== Sync tamamlandı ===${NC}"
echo "  MN5 yolu: ${MN5_DEST}"
echo ""
echo "  Bağlanmak için:"
echo "    ssh ${MN5_USER}@alogin1.bsc.es"
echo "    cd ${MN5_DEST}"
