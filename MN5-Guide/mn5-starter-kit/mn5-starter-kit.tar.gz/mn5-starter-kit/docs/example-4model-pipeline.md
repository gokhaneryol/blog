# Gerçek Dünya Örneği: 4 Model, 4 GPU, 4 Aşamalı Pipeline

> **Senaryo:** MareNostrum5'te tek bir node üzerindeki 4 H100 GPU'ya 4 farklı açık kaynaklı LLM yerleştiriyoruz. Bu modelleri bir orchestrator arkasında sunuyoruz ve ardından bir kullanıcı sorusunu sıralı olarak dört modelden geçiren bir pipeline çalıştırıyoruz.
>
> Bu senaryo, **PRIVOAI** projesinin MN5 Faz 2 milestone'undan gerçek bir çalışmayı belgelemektedir. Job ID: `38454163`, tarih: 1 Nisan 2026.

---

## İçindekiler

1. [Neden Bu Mimari?](#1-neden-bu-mimari)
2. [Altyapı Özeti](#2-altyapı-özeti)
3. [Ön Hazırlık: Modelleri İndirmek](#3-ön-hazırlık-modelleri-i̇ndirmek)
4. [Orchestrator Scripti](#4-orchestrator-scripti)
5. [Pipeline Demo Scripti](#5-pipeline-demo-scripti)
6. [SLURM Job Scripti](#6-slurm-job-scripti)
7. [Job Gönderme ve İzleme](#7-job-gönderme-ve-i̇zleme)
8. [Curl ile Manuel Test](#8-curl-ile-manuel-test)
9. [Gerçek Çalışma Çıktısı](#9-gerçek-çalışma-çıktısı)
10. [Ne Öğrendik: Kritik Teknik Notlar](#10-ne-öğrendik-kritik-teknik-notlar)
11. [Sonraki Adımlar](#11-sonraki-adımlar)

---

## 1. Neden Bu Mimari?

Büyük dil modellerini HPC üzerinde çalıştırmak için birden fazla yol vardır. Bunlardan en sık tercih edilen ikisi şunlardır:

**Tensor Parallelism (1 model → N GPU):** Tek bir büyük modeli birden fazla GPU'ya bölerek daha hızlı inference elde edersiniz. Örneğin 70B parametreli bir model 4 GPU'ya yayılabilir. Ancak tüm GPU'lar tek bir model için harcanır.

**Data Parallelism (N model → N GPU):** Her GPU'da ayrı bir model instance çalışır. Modeller farklı olabilir. Her model bağımsız bir HTTP sunucusu olarak hizmet verir. Bir orchestrator bu sunuculara istek yönlendirir.

PRIVOAI projesinde ikinci yaklaşım benimsendi: her modelin farklı bir role sahip olduğu **çok-ajanlı** bir sistem tasarlanıyor. 4B'lik hafif bir model soruyu netleştirir, 8B'lik daha güçlü model analiz yapar, başka bir model eleştiri ekler, son model sentez yapar. Bu mimari için her GPU'da farklı bir model olması gerekir.

---

## 2. Altyapı Özeti

| Bileşen | Değer |
|---|---|
| Platform | MareNostrum5 ACC partition |
| Node | 1 node |
| GPU | 4 × NVIDIA H100 80 GB SXM5 |
| CPU | 80 core (Intel Sapphire Rapids) |
| RAM | 512 GB |
| Container runtime | Singularity / Apptainer |
| Container image | `vllm-v0.18.0-official.sif` (BSC AI Hub) |
| Inference framework | vLLM 0.18.0 |

### GPU — Model Eşlemesi

| GPU | Port | Model | Alias | Parametre |
|---|---|---|---|---|
| GPU 0 | 8000 | `google/gemma-3-4b-it` | `gemma3` | 4B |
| GPU 1 | 8001 | `mistralai/Mistral-7B-Instruct-v0.3` | `mistral` | 7B |
| GPU 2 | 8002 | `meta-llama/Llama-3.1-8B-Instruct` | `llama3` | 8B |
| GPU 3 | 8003 | `google/gemma-2-9b` | `gemma2` | 9B |
| — | 9000 | Orchestrator | — | — |

### Container Seçimi

BSC, `vllm-v0.18.0-official.sif` adlı hazır bir container sağlıyor:

```
/gpfs/scratch/shared/ai-hub/singularity_images/vllm/vllm-v0.18.0-official.sif
```

Bu image'ı tercih etmenizin iki pratik nedeni var. Birincisi, indirmenize gerek yok — doğrudan yol vererek kullanabilirsiniz. İkincisi, `transformers==4.57.6` içeriyor; bu sürüm Gemma 3 (`model_type=gemma3`) mimarisini destekliyor. Eğer kendiniz bir Docker image derleseydınız ve `transformers==4.46.3` gibi eski bir sürüm kullansaydınız Gemma 3 yüklenirken hata alırdınız.

---

## 3. Ön Hazırlık: Modelleri İndirmek

MN5 login node'larında internet bağlantısı **yoktur**. Modelleri önce yerel makinenizde indirip ardından transfer etmeniz gerekir. Alternatif olarak, eğer MN5'e bağlanacak başka bir sunucunuzda HuggingFace erişimi varsa oradan da kopyalayabilirsiniz.

### Yerel Makinede İndirme

```bash
# Yerel makinede Python venv kur
python3 -m venv hf-env
source hf-env/bin/activate
pip install huggingface_hub

# İndirme scripti (download_models.py)
python3 - <<'EOF'
from huggingface_hub import snapshot_download
import os

models = [
    "google/gemma-3-4b-it",
    "mistralai/Mistral-7B-Instruct-v0.3",
    "meta-llama/Llama-3.1-8B-Instruct",
    "google/gemma-2-9b",
]

for model_id in models:
    print(f"\nİndiriliyor: {model_id}")
    snapshot_download(
        repo_id=model_id,
        local_dir=f"./models/{model_id}",
        ignore_patterns=["*.msgpack", "flax_model*", "tf_model*"],
    )
    print(f"Tamamlandı: {model_id}")
EOF
```

**Not:** Llama 3 ve Gemma modelleri için HuggingFace'de lisans onayı gerekiyor. `huggingface-cli login` komutuyla token'ınızı ekleyin ve modelin kartındaki lisansı kabul edin.

### MN5'e Transfer

```bash
# Modeller büyük (toplam ~30 GB) — rsync ile parçalı transfer
rsync -avz --partial --progress \
  ./models/ \
  KULLANICI@transfer1.bsc.es:/gpfs/projects/ehpc648/models/
```

Transfer1 node'u bu tür büyük transferler için önerilir; login node üzerinden transfer yapmak hem daha yavaştır hem de diğer kullanıcıları etkiler.

---

## 4. Orchestrator Scripti

Bu script, 4 vLLM backend'ini tek bir API arkasında toplar. Model adına göre doğru backend'e yönlendirir.

`scripts/orchestrator_multimodel.py` dosyasını oluşturun:

```python
#!/usr/bin/env python3
"""
PRIVOAI Multi-Model Orchestrator
Birden fazla vLLM backend'ini tek bir API arkasında toplar.
Model alias'ına göre doğru backend'e yönlendirir.

Kullanım:
  BACKENDS_JSON="gemma3=http://host:8000,mistral=http://host:8001" \
    python3 orchestrator_multimodel.py --port 9000
"""

import os
import json
import argparse
import logging
import requests
from flask import Flask, request, jsonify

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger(__name__)

app = Flask(__name__)

# Backend'leri BACKENDS_JSON ortam değişkeninden oku
# Format: "alias=http://host:port,alias2=http://host:port2"
BACKENDS: dict[str, str] = {}

def load_backends():
    raw = os.environ.get("BACKENDS_JSON", "")
    if not raw:
        logger.warning("BACKENDS_JSON ortam değişkeni boş — backend yok.")
        return
    for entry in raw.split(","):
        if "=" in entry:
            alias, url = entry.split("=", 1)
            BACKENDS[alias.strip()] = url.strip().rstrip("/")
            logger.info(f"  Backend: {alias.strip()} → {url.strip()}")


def pick_backend(model: str) -> tuple[str, str] | tuple[None, None]:
    """
    Model adıyla eşleşen backend'i döner.
    Önce tam eşleşme, sonra kısmi eşleşme, son çare round-robin.
    """
    if model in BACKENDS:
        return model, BACKENDS[model]
    for alias, url in BACKENDS.items():
        if alias in model or model in alias:
            return alias, url
    if BACKENDS:
        alias = next(iter(BACKENDS))
        return alias, BACKENDS[alias]
    return None, None


@app.route("/health", methods=["GET"])
def health():
    """Tüm backend'lerin durumunu kontrol eder."""
    statuses = {}
    for alias, url in BACKENDS.items():
        try:
            r = requests.get(f"{url}/health", timeout=2)
            statuses[alias] = "ok" if r.status_code == 200 else f"http_{r.status_code}"
        except Exception as e:
            statuses[alias] = f"error: {e}"
    all_ok = all(v == "ok" for v in statuses.values())
    return jsonify({"status": "ok" if all_ok else "degraded", "backends": statuses})


@app.route("/v1/models", methods=["GET"])
def list_models():
    """Tüm alias'ları OpenAI format'ında listeler."""
    models = [{"id": alias, "object": "model"} for alias in BACKENDS]
    return jsonify({"object": "list", "data": models})


@app.route("/infer", methods=["POST"])
def infer():
    """PRIVOAI native inference endpoint — model alanına göre yönlendirir."""
    body = request.get_json(force=True)
    model = body.get("model", "")
    alias, url = pick_backend(model)
    if url is None:
        return jsonify({"error": "Hiç backend yok"}), 503
    logger.info(f"  /infer → {alias} ({url})")
    try:
        r = requests.post(f"{url}/v1/completions", json={
            "model": alias,
            "prompt": body.get("prompt", ""),
            "max_tokens": body.get("max_tokens", 256),
            "temperature": body.get("temperature", 0.7),
        }, timeout=120)
        return jsonify(r.json()), r.status_code
    except Exception as e:
        return jsonify({"error": str(e)}), 502


@app.route("/v1/completions", methods=["POST"])
def completions():
    """OpenAI-uyumlu completions proxy."""
    body = request.get_json(force=True)
    model = body.get("model", "")
    alias, url = pick_backend(model)
    if url is None:
        return jsonify({"error": "Hiç backend yok"}), 503
    logger.info(f"  /v1/completions → {alias} ({url})")
    try:
        body["model"] = alias
        r = requests.post(f"{url}/v1/completions", json=body, timeout=120)
        return jsonify(r.json()), r.status_code
    except Exception as e:
        return jsonify({"error": str(e)}), 502


@app.route("/v1/chat/completions", methods=["POST"])
def chat_completions():
    """OpenAI-uyumlu chat completions proxy."""
    body = request.get_json(force=True)
    model = body.get("model", "")
    alias, url = pick_backend(model)
    if url is None:
        return jsonify({"error": "Hiç backend yok"}), 503
    logger.info(f"  /v1/chat/completions → {alias} ({url})")
    try:
        body["model"] = alias
        r = requests.post(f"{url}/v1/chat/completions", json=body, timeout=120)
        return jsonify(r.json()), r.status_code
    except Exception as e:
        return jsonify({"error": str(e)}), 502


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=9000)
    parser.add_argument("--host", default="0.0.0.0")
    args = parser.parse_args()

    load_backends()
    logger.info(f"Orchestrator başlıyor — port {args.port}")
    app.run(host=args.host, port=args.port, threaded=True)
```

---

## 5. Pipeline Demo Scripti

Bu script, dört modeli sıralı olarak çağırır. Her aşamanın çıktısı sonraki aşamanın girişine eklenir.

`scripts/pipeline_demo.py` dosyasını oluşturun:

```python
#!/usr/bin/env python3
"""
PRIVOAI 4-Aşamalı Pipeline Demo

Sıra:
  Stage 1: gemma3  — Clarifier  (soruyu netleştirir)
  Stage 2: mistral — Analyst    (detaylı analiz üretir)
  Stage 3: llama3  — Critic     (analizi eleştirir, tamamlar)
  Stage 4: gemma2  — Synthesizer (tek özlü yanıtta toplar)

Kullanım:
  python3 pipeline_demo.py \
    --orchestrator "http://<NODE>:9000" \
    --prompt "Your question here" \
    --output results/pipeline_output.jsonl
"""

import argparse
import json
import time
import requests


PIPELINE_STAGES = [
    {
        "name": "Stage 1 — Clarifier",
        "model": "gemma3",
        "role": "clarifier",
        "system": (
            "You are a clarifier. Your job is to restate the user's question "
            "more precisely, identify the key sub-questions, and specify any "
            "assumptions you are making. Be concise."
        ),
        "max_tokens": 128,
        "temperature": 0.3,
    },
    {
        "name": "Stage 2 — Analyst",
        "model": "mistral",
        "role": "analyst",
        "system": (
            "You are a thorough analyst. Based on the refined question provided, "
            "produce a detailed, structured analysis. Cover main points, risks, "
            "and trade-offs."
        ),
        "max_tokens": 512,
        "temperature": 0.7,
    },
    {
        "name": "Stage 3 — Critic",
        "model": "llama3",
        "role": "critic",
        "system": (
            "You are a critical reviewer. Review the analysis provided and identify "
            "gaps, incorrect assumptions, or missing perspectives. Provide a more "
            "complete or corrected version."
        ),
        "max_tokens": 512,
        "temperature": 0.7,
    },
    {
        "name": "Stage 4 — Synthesizer",
        "model": "gemma2",
        "role": "synthesizer",
        "system": (
            "You are a synthesizer. Read all previous stages and write a clear, "
            "concise final answer in 3–5 sentences. No bullet points."
        ),
        "max_tokens": 160,
        "temperature": 0.5,
    },
]


def call_model(orchestrator_url: str, stage: dict, prompt: str) -> dict:
    """Orchestrator üzerinden tek bir aşamayı çağırır."""
    payload = {
        "model": stage["model"],
        "messages": [
            {"role": "system", "content": stage["system"]},
            {"role": "user", "content": prompt},
        ],
        "max_tokens": stage["max_tokens"],
        "temperature": stage["temperature"],
    }
    t0 = time.time()
    r = requests.post(
        f"{orchestrator_url}/v1/chat/completions",
        json=payload,
        timeout=180,
    )
    r.raise_for_status()
    data = r.json()
    elapsed = time.time() - t0

    choice = data["choices"][0]["message"]["content"]
    usage = data.get("usage", {})
    return {
        "stage": stage["name"],
        "model": stage["model"],
        "role": stage["role"],
        "elapsed_s": round(elapsed, 2),
        "prompt_tokens": usage.get("prompt_tokens", 0),
        "completion_tokens": usage.get("completion_tokens", 0),
        "output": choice,
    }


def run_pipeline(orchestrator_url: str, user_prompt: str) -> list[dict]:
    """4 aşamalı pipeline'ı çalıştırır ve sonuçları döner."""
    results = []
    context = user_prompt

    print(f"\n{'='*60}")
    print(f"PRIVOAI 4-Aşamalı Pipeline")
    print(f"Soru: {user_prompt[:80]}{'...' if len(user_prompt) > 80 else ''}")
    print(f"{'='*60}\n")

    for i, stage in enumerate(PIPELINE_STAGES):
        print(f"[{stage['name']}] çalışıyor ({stage['model']})...")

        if i == 0:
            prompt = user_prompt
        else:
            # Önceki aşamaların çıktısını bağlam olarak ekle
            context_parts = [f"Original question: {user_prompt}"]
            for prev in results:
                context_parts.append(
                    f"\n{prev['stage']} ({prev['model']}) output:\n{prev['output']}"
                )
            prompt = "\n".join(context_parts)

        result = call_model(orchestrator_url, stage, prompt)
        results.append(result)

        print(f"  Süre: {result['elapsed_s']} sn | "
              f"Tokens: {result['prompt_tokens']} in / {result['completion_tokens']} out")
        print(f"  Çıktı: {result['output'][:120]}...\n")

    # Özet tablo
    total_time = sum(r["elapsed_s"] for r in results)
    total_in = sum(r["prompt_tokens"] for r in results)
    total_out = sum(r["completion_tokens"] for r in results)

    print(f"\n{'='*60}")
    print(f"ÖZET")
    print(f"{'='*60}")
    print(f"{'Aşama':<25} {'Model':<10} {'Süre':>8} {'In tok':>8} {'Out tok':>8}")
    print(f"{'-'*60}")
    for r in results:
        print(f"{r['stage']:<25} {r['model']:<10} "
              f"{r['elapsed_s']:>7.2f}s {r['prompt_tokens']:>8} {r['completion_tokens']:>8}")
    print(f"{'-'*60}")
    print(f"{'TOPLAM':<36} {total_time:>7.2f}s {total_in:>8} {total_out:>8}")
    print(f"{'='*60}\n")

    return results


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--orchestrator", required=True,
                        help="Orchestrator URL (örn: http://nodeX:9000)")
    parser.add_argument("--prompt", required=True, help="Kullanıcı sorusu")
    parser.add_argument("--output", default="results/pipeline_output.jsonl",
                        help="Çıktı dosyası (.jsonl)")
    args = parser.parse_args()

    results = run_pipeline(args.orchestrator, args.prompt)

    import os
    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    with open(args.output, "w") as f:
        for r in results:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"Sonuçlar kaydedildi: {args.output}")
```

---

## 6. SLURM Job Scripti

Bu script, bir job içinde 4 vLLM instance başlatır, orchestrator'ı ayağa kaldırır, health check yapar ve pipeline'ı çalıştırır.

`jobs/vllm_4model_pipeline.slurm` dosyasını oluşturun:

```bash
#!/bin/bash
#SBATCH --job-name=ph02-4model
#SBATCH --account=ehpc648
#SBATCH --qos=acc_debug
#SBATCH --partition=acc
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=80
#SBATCH --gres=gpu:4
#SBATCH --mem=400G
#SBATCH --time=02:00:00
#SBATCH --output=logs/%x-%j.out
#SBATCH --error=logs/%x-%j.err

# ---------------------------------------------------------------------------
# Ortam
# ---------------------------------------------------------------------------
module purge
module load singularity/3.11.5

SIF="/gpfs/scratch/shared/ai-hub/singularity_images/vllm/vllm-v0.18.0-official.sif"
MODEL_BASE="/gpfs/projects/ehpc648/models"
PROJECT_DIR="/gpfs/projects/ehpc648/my-project"
NODE=$(hostname)

# ---------------------------------------------------------------------------
# Model tanımları
# ---------------------------------------------------------------------------
declare -A MODEL_PATH
MODEL_PATH[0]="google/gemma-3-4b-it"
MODEL_PATH[1]="mistralai/Mistral-7B-Instruct-v0.3"
MODEL_PATH[2]="meta-llama/Llama-3.1-8B-Instruct"
MODEL_PATH[3]="google/gemma-2-9b"

declare -A MODEL_ALIAS
MODEL_ALIAS[0]="gemma3"
MODEL_ALIAS[1]="mistral"
MODEL_ALIAS[2]="llama3"
MODEL_ALIAS[3]="gemma2"

declare -A MODEL_MAXLEN
MODEL_MAXLEN[0]=4096
MODEL_MAXLEN[1]=8192
MODEL_MAXLEN[2]=8192
MODEL_MAXLEN[3]=4096

BASE_PORT=8000
ORCH_PORT=9000

echo "=== 4-Model Pipeline Job başladı: $(date) ==="
echo "  Job ID : $SLURM_JOB_ID"
echo "  Node   : $NODE"

mkdir -p logs

# ---------------------------------------------------------------------------
# 4 vLLM instance başlat — her GPU için ayrı background process
# KRITIK: CUDA_VISIBLE_DEVICES=${GPU_ID} → fiziksel GPU seçimi
#         SINGULARITYENV_CUDA_VISIBLE_DEVICES=0 → container içinde her zaman 0
# ---------------------------------------------------------------------------
VLLM_PIDS=()
for GPU_ID in 0 1 2 3; do
  PORT=$((BASE_PORT + GPU_ID))
  ALIAS=${MODEL_ALIAS[$GPU_ID]}
  MODEL=${MODEL_PATH[$GPU_ID]}
  MAXLEN=${MODEL_MAXLEN[$GPU_ID]}

  echo "  [GPU ${GPU_ID}] ${ALIAS} → port ${PORT}"

  CUDA_VISIBLE_DEVICES=${GPU_ID} \
  SINGULARITYENV_CUDA_VISIBLE_DEVICES=0 \
    singularity exec --nv \
      --bind "${MODEL_BASE}:/models" \
      --bind "${PROJECT_DIR}:/workspace" \
      "${SIF}" \
      python3 -m vllm.entrypoints.openai.api_server \
        --model "/models/${MODEL}" \
        --served-model-name "${ALIAS}" \
        --tensor-parallel-size 1 \
        --port "${PORT}" \
        --host 0.0.0.0 \
        --trust-remote-code \
        --gpu-memory-utilization 0.90 \
        --max-model-len "${MAXLEN}" \
        >> "logs/vllm-${ALIAS}-${SLURM_JOB_ID}.log" 2>&1 &

  VLLM_PIDS+=($!)
done

echo ""
echo "=== vLLM instance'ları başlatıldı. Health check bekleniyor... ==="

# ---------------------------------------------------------------------------
# Health check — her port hazır olana kadar bekle (max 3 dakika)
# ---------------------------------------------------------------------------
ALL_READY=1
for GPU_ID in 0 1 2 3; do
  PORT=$((BASE_PORT + GPU_ID))
  ALIAS=${MODEL_ALIAS[$GPU_ID]}
  echo -n "  [${ALIAS}:${PORT}] bekleniyor"
  READY=0
  for i in $(seq 1 18); do
    if curl -s "http://localhost:${PORT}/health" 2>/dev/null | grep -q "ok"; then
      echo " → HAZIR (${i}x10 sn)"
      READY=1
      break
    fi
    echo -n "."
    sleep 10
  done
  if [ $READY -eq 0 ]; then
    echo " → ZAMAN AŞIMI"
    ALL_READY=0
  fi
done

if [ $ALL_READY -eq 0 ]; then
  echo "HATA: Bazı modeller hazır olmadı. Logları kontrol edin."
  exit 1
fi

# ---------------------------------------------------------------------------
# Orchestrator başlat
# ---------------------------------------------------------------------------
BACKENDS_JSON="gemma3=http://localhost:${BASE_PORT},mistral=http://localhost:$((BASE_PORT+1)),llama3=http://localhost:$((BASE_PORT+2)),gemma2=http://localhost:$((BASE_PORT+3))"

BACKENDS_JSON="${BACKENDS_JSON}" \
  singularity exec --nv \
    --bind "${PROJECT_DIR}:/workspace" \
    "${SIF}" \
    python3 /workspace/scripts/orchestrator_multimodel.py \
      --port ${ORCH_PORT} \
      >> "logs/orchestrator-${SLURM_JOB_ID}.log" 2>&1 &
ORCH_PID=$!

# Orchestrator'ın hazır olmasını bekle
sleep 5

echo ""
echo "=== MODELLER HAZIR ==="
echo "  Node: ${NODE}"
for GPU_ID in 0 1 2 3; do
  PORT=$((BASE_PORT + GPU_ID))
  ALIAS=${MODEL_ALIAS[$GPU_ID]}
  echo "  ${ALIAS} → http://${NODE}:${PORT}/v1"
done
echo "  orch → http://${NODE}:${ORCH_PORT}"
echo ""
echo "  SSH tüneli (yerel makinede):"
echo "    ssh -L 8000:${NODE}:8000 -L 8001:${NODE}:8001 \\"
echo "        -L 8002:${NODE}:8002 -L 8003:${NODE}:8003 \\"
echo "        -L 9000:${NODE}:9000 \$USER@alogin1.bsc.es"

# ---------------------------------------------------------------------------
# Pipeline demo çalıştır
# ---------------------------------------------------------------------------
echo ""
echo "=== Pipeline demo başlatılıyor ==="

DEMO_PROMPT="What are the key privacy risks in deploying an AI system in a regulated environment, and how can they be mitigated?"

singularity exec --nv \
  --bind "${PROJECT_DIR}:/workspace" \
  "${SIF}" \
  python3 /workspace/scripts/pipeline_demo.py \
    --orchestrator "http://localhost:${ORCH_PORT}" \
    --prompt "${DEMO_PROMPT}" \
    --output "/workspace/results/pipeline_demo_${SLURM_JOB_ID}.jsonl"

echo ""
echo "=== Pipeline demo tamamlandı: $(date) ==="

# ---------------------------------------------------------------------------
# Tüm background process'leri temizle
# ---------------------------------------------------------------------------
for PID in "${VLLM_PIDS[@]}"; do
  kill "${PID}" 2>/dev/null || true
done
kill "${ORCH_PID}" 2>/dev/null || true

wait
echo "=== Job bitti: $(date) ==="
```

---

## 7. Job Gönderme ve İzleme

Tüm scriptleri MN5'e sync ettikten sonra:

```bash
# MN5'e bağlan
ssh KULLANICI@alogin1.bsc.es
cd /gpfs/projects/ehpc648/my-project

# Dizinleri kontrol et
ls scripts/
ls jobs/

# Job gönder
sbatch jobs/vllm_4model_pipeline.slurm

# Job ID'yi öğren ve takip et
squeue -u $USER

# Logları canlı izle
tail -f logs/ph02-4model-JOBID.out
```

Tipik bir node bekleme süresi `acc_debug` QoS için 1–5 dakikadır. Job başladığında terminalde şunu göreceksiniz:

```
=== 4-Model Pipeline Job başladı: Wed Apr  1 14:22:18 UTC 2026
  Job ID : 38454163
  Node   : as01r5b08
  [GPU 0] gemma3 → port 8000
  [GPU 1] mistral → port 8001
  [GPU 2] llama3 → port 8002
  [GPU 3] gemma2 → port 8003

=== vLLM instance'ları başlatıldı. Health check bekleniyor... ===
  [gemma3:8000] bekleniyor..........
  [mistral:8001] bekleniyor. → HAZIR (2x10 sn)
  [llama3:8002] bekleniyor → HAZIR (1x10 sn)
  [gemma2:8003] bekleniyor.. → HAZIR (3x10 sn)
  [gemma3:8000] → HAZIR (10x10 sn)
```

Gemma 3, multi-modal mimarisi nedeniyle ~90 saniye yükleniyor. Diğerleri çok daha hızlı.

---

## 8. Curl ile Manuel Test

Node hazır olduktan sonra login node üzerinden veya SSH tüneliyle yerel makinenizden test edebilirsiniz.

```bash
NODE=as01r5b08   # kendi log'unuzdan alın

# Her modeli ayrı ayrı test et
curl http://${NODE}:8000/v1/completions \
  -H "Content-Type: application/json" \
  -d '{"model": "gemma3", "prompt": "Explain privacy in one sentence.", "max_tokens": 50}'

curl http://${NODE}:8001/v1/completions \
  -H "Content-Type: application/json" \
  -d '{"model": "mistral", "prompt": "Explain differential privacy.", "max_tokens": 100}'

# Orchestrator üzerinden model seçerek
curl http://${NODE}:9000/infer \
  -H "Content-Type: application/json" \
  -d '{"model": "llama3", "prompt": "What is federated learning?", "max_tokens": 100}'

# Tüm modelleri listele
curl http://${NODE}:9000/v1/models

# Orchestrator sağlık durumu
curl http://${NODE}:9000/health
```

### Yerel Makineden SSH Tüneli

```bash
# Tüm portları tünel et
ssh -N \
  -L 8000:as01r5b08:8000 \
  -L 8001:as01r5b08:8001 \
  -L 8002:as01r5b08:8002 \
  -L 8003:as01r5b08:8003 \
  -L 9000:as01r5b08:9000 \
  KULLANICI@alogin1.bsc.es

# Tünel kurulduktan sonra yerel makineden:
curl http://localhost:9000/health
curl http://localhost:9000/v1/models
```

---

## 9. Gerçek Çalışma Çıktısı

Job `38454163` çıktısından alınan gerçek pipeline sonucu (1 Nisan 2026):

**Giriş sorusu:**
> *"What are the key privacy risks in deploying an AI system in a regulated environment, and how can they be mitigated?"*

---

**Stage 1 — Clarifier (gemma3, 0.29 sn):**

> *"What specific privacy risks arise when deploying an AI system within a regulated industry (please specify the industry if known), and what are the most effective mitigation strategies for each identified risk?"*

Soruyu netleştirdi, sektör bilgisini ekledi, risklerin her biri için strateji istedi.

---

**Stage 2 — Analyst (mistral, 4.13 sn, 384 token):**

> *"Industry: Healthcare. Privacy Risks: 1. Data Breaches: AI systems often require large amounts of data, including sensitive patient information... 2. Inadequate Consent: AI systems may process personal health data without obtaining proper consent... 3. Data Misuse... 4. Data Quality and Integrity... 5. Oversharing of Information..."*

Her risk için mitigation stratejileri listeledi.

---

**Stage 3 — Critic (llama3, 4.43 sn, 384 token):**

> *"The previous analysis is a good start, but it lacks depth and specificity... 1. Data Breaches: A breach at a major healthcare provider in 2020 resulted in the theft of sensitive patient information, including Social Security numbers and medical records... 2. Inadequate Consent: a study found that 70% of patients were unaware that their medical records were being used for research purposes..."*

Somut örnekler ve istatistikler ekleyerek analizi derinleştirdi.

---

**Stage 4 — Synthesizer (gemma2, 1.26 sn, 80 token):**

> *"The key privacy risks in deploying an AI system in a regulated environment include data breaches, inadequate consent, and data misuse. To mitigate these risks, healthcare providers should implement robust data security measures, obtain proper consent from patients, and ensure that AI systems are used for intended purposes only. Additionally, healthcare providers should consider implementing a data governance framework to manage patient data effectively and comply with privacy regulations."*

---

**Pipeline Metrikleri:**

| Aşama | Model | Rol | Süre | Giriş tok. | Çıkış tok. |
|---|---|---|---|---|---|
| Stage 1 | gemma3 | Clarifier | 0.29 sn | 69 | 38 |
| Stage 2 | mistral | Analyst | 4.13 sn | 76 | 384 |
| Stage 3 | llama3 | Critic | 4.43 sn | 370 | 384 |
| Stage 4 | gemma2 | Synthesizer | 1.26 sn | 463 | 80 |
| **Toplam** | | | **10.11 sn** | **978** | **886** |

Dört modelin sıralı çalıştığı, her birinin önceki çıktıyı bağlam olarak aldığı bu zincir toplamda ~10 saniyede tamamlandı. Tüm işlem tek bir H100 node'unda, tamamen çevrimdışı ve özgür yazılım araçlarıyla gerçekleşti.

---

## 10. Ne Öğrendik: Kritik Teknik Notlar

Bu çalışma boyunca birkaç önemli bulgu ortaya çıktı.

### `--gpu-bind=single:1` Singularity'ye Yansımaz

SLURM'un `--gpu-bind=single:1` direktifi GPU izolasyonunu cgroup seviyesinde sağlar, ancak bu izolasyon Singularity container'ının içine yansımaz. Container, NVML üzerinden GPU'yu sorgularken her zaman index 0'ı görür. Bu nedenle tüm GPU ID'leri `0` görünüyor ve tüm modeller aynı GPU'ya yüklenmeye çalışıyordu; OOM hatası alınıyordu.

**Çözüm:** Her container'ı başlatırken hem `CUDA_VISIBLE_DEVICES` hem de `SINGULARITYENV_CUDA_VISIBLE_DEVICES` değişkenlerini açıkça set edin:

```bash
# Fiziksel GPU seçimi (host tarafında)
CUDA_VISIBLE_DEVICES=${GPU_ID} \
# Container'ın göreceği index (her zaman 0)
SINGULARITYENV_CUDA_VISIBLE_DEVICES=0 \
  singularity exec --nv ...
```

SLURM cgroup'u fiziksel GPU'yu ayırır; container içinde her model kendi GPU'sunu "index 0" olarak görür.

### `module load python` Container'ı Bozar

`module load python` komutu `PYTHONHOME` ve `PYTHONPATH` değişkenlerini set eder. Bu değişkenler Singularity'ye sızarak container'ın Python kurulumunu override eder, import hataları oluşur.

**Çözüm:** Job script'inin başında yalnızca şunu yapın:

```bash
module purge
module load singularity/3.11.5
```

Python bağımlılıkları için container'a güvenin.

### BSC AI Hub Container'ı Kullanın

Kendi Docker image'ınızı derlemenize gerek yok. BSC'nin sağladığı `vllm-v0.18.0-official.sif` image'ı güncel `transformers==4.57.6` içeriyor. Bu sürüm Gemma 3 (`model_type=gemma3`) desteğini getiriyor; daha eski sürümlerde Gemma 3 modeli yüklenirken `KeyError: 'gemma3'` hatası alıyordunuz.

### Model Yükleme Sürelerindeki Fark Neden Önemli

Gemma 3 (4B, 2 shard) ~90 saniye yüklenirken Mistral 7B (1 shard) ~10 saniyede yükleniyordu. Bu fark shard sayısıyla değil, multi-modal işlemcinin hazırlanması ve ağırlık dosyası formatıyla ilgili. Birden fazla model başlatıyorsanız en yavaş modelin hazır olmasını beklemeniz gerekiyor; health check döngüsü bu senkronizasyonu sağlıyor.

---

## 11. Sonraki Adımlar

Bu çalışmanın üzerine birkaç yönde ilerleme planlanıyor:

**Model kalite karşılaştırması:** Aynı soruların 4 modele gönderildiği, latency ve yanıt kalitesinin ölçüldüğü sistematik bir benchmark. Hangi modelin hangi role (clarifier, analyst, critic, synthesizer) en uygun olduğunu veriye dayalı belirlemek.

**Instruction-tuned Gemma 2:** `google/gemma-2-9b-it` versiyonu pipeline'da temel `gemma-2-9b`'nin yerini alabilir; instruction following kalitesinin değerlendirilmesi planlanıyor.

**SecBERT entegrasyonu:** Encoder-only (BERT tabanlı) modeller vLLM'de completions API'siyle serve edilemiyor. Bunlar için ayrı bir FastAPI servisi yazılması ve pipeline'ın Stage 0 olarak bir sınıflandırma aşaması içermesi düşünülüyor.

**Çoklu istek testi:** Eşzamanlı N=1, 4, 8, 16 istek altında pipeline throughput'unun ölçülmesi.

**Multi-node genişleme:** 2 node (8 GPU) konfigürasyonunda büyük model (13B+) inference; `NCCL_NET=IB`, `NCCL_SOCKET_IFNAME=ib0` değişkenleriyle InfiniBand üzerinden iletişim.

---

*Bu örnek, PRIVOAI projesinin MN5 Faz 2 çalışmasından gerçek bir senaryoyu belgelemektedir.*
*İletişim: Gökhan Eryol — gokhaneryol@gmail.com*
